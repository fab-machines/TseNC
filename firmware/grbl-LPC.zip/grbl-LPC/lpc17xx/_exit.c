void _exit()
{
    while (1)
        ;
}
